from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host, port, database, collection):
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = host
        PORT = port
        DB = database
        COL = collection
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# try catch statements used for create, read, update, and delete
# in order to implement exception handling

# Method to Implement C, for create, in CRUD
    def create(self, data):
        try:
            if data is not None: # verify data exists/not empty value
                result = self.database.animals.insert_one(data)
                return True if result.inserted_id else False
  
        except Exception as e:
            print(f"Error inserting: {e}")
            return False

# Method to Implement R, for read, in CRUD
    def read(self, query):
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        
        except Exception as e: 
            print(f"Error querying: {e}")
            return[]
          
#Method to Implement U, for update, in CRUD
    def update(self, query, update_data): 
        try:
            result = self.collection.update_many(query, {'$set': update_data})
            return result.modified_count
          
        except Exception as e: 
            print(f"Error updating: {e}")
            return 0

#Method to Implement D, for delete, in CRUD
    def delete(self, query):
        try: 
            result = self.collection.delete_many(query)
            return result.deleted_count
          
        except Exception as e: 
            print(f"Error deleting: {e}")
            return 0 
